<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Experius_MultipleWebsiteStoreCodeUrl',
    __DIR__
);
